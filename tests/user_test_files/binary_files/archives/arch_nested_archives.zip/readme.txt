Outer archive with nested ZIP inside
